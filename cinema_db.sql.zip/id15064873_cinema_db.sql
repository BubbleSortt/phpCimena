-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Хост: localhost:3306
-- Время создания: Ноя 14 2020 г., 14:39
-- Версия сервера: 10.3.16-MariaDB
-- Версия PHP: 7.3.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `id15064873_cinema_db`
--

-- --------------------------------------------------------

--
-- Структура таблицы `favorites`
--

DROP TABLE IF EXISTS `favorites`;
CREATE TABLE `favorites` (
  `film_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `favorites`
--

INSERT INTO `favorites` (`film_id`, `user_id`) VALUES
(2, 1),
(4, 1),
(6, 1),
(8, 1),
(1, 2),
(5, 2),
(7, 2);

-- --------------------------------------------------------

--
-- Структура таблицы `films`
--

DROP TABLE IF EXISTS `films`;
CREATE TABLE `films` (
  `id` int(11) NOT NULL,
  `add_date` date DEFAULT NULL,
  `title` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `categorie_id` int(11) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `films`
--

INSERT INTO `films` (`id`, `add_date`, `title`, `description`, `categorie_id`, `image`) VALUES
(1, NULL, 'Мстители. Война Бесконечности', '', 1, 'https://sun9-69.userapi.com/sf-iOZ3awLy58OkViMW8Anhvl4vuVjHavW2ozw/HRujtqIMjKY.jpg'),
(2, NULL, 'Паразиты', '', 1, 'https://www.buro247.ua/thumb/670x830_0/images/2020/02/film-parazity-stanet-komiksom-01.jpg'),
(4, NULL, 'Матрица', '', 1, 'https://avatars.mds.yandex.net/get-kinopoisk-image/1704946/eed1de3a-5400-43b3-839e-22490389bf54/360'),
(5, NULL, 'Ветер крпчает', '', 1, 'https://avatars.mds.yandex.net/get-kinopoisk-image/1777765/3c9f202b-f25f-4d64-a088-b67d49477de2/x1000'),
(6, NULL, 'Джуманджи: новый уровень', '', 2, 'https://www.film.ru/sites/default/files/movies/posters/38965946-1125932.jpg'),
(7, NULL, 'Довод', '', 2, 'https://images11.esquire.ru/upload/custom/0f8/0f8d0473d2d12466129beed75f94c9ee.jpg'),
(8, NULL, 'Соник в кино', '', 2, 'https://avatars.mds.yandex.net/get-zen_doc/1931664/pub_5d28f6c543bee300ae19bb95_5d28f6f9c31e4900aebf3a14/scale_1200'),
(9, NULL, 'Скуби - Ду', '', 2, 'https://irecommend.ru/sites/default/files/product-images/163999/CSGHwAGjBxbyafjJRPliQ.jpg'),
(10, NULL, 'Человек-паук: Через вселенные', '', 1, 'https://www.kinopoisk.ru/images/film_big/920265.jpg'),
(35, '2020-11-12', 'Ледниковый период', 'Очень интересный', 1, '/storage/ssd2/873/15064873/public_html/static/images/b8a76da8.jpg'),
(36, '2020-11-12', 'Патриот', 'не очень интересный', 2, '/storage/ssd2/873/15064873/public_html/static/images/b8a76da8.jpg');

-- --------------------------------------------------------

--
-- Структура таблицы `fim_categorie`
--

DROP TABLE IF EXISTS `fim_categorie`;
CREATE TABLE `fim_categorie` (
  `id` int(11) NOT NULL,
  `categorie_title` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `fim_categorie`
--

INSERT INTO `fim_categorie` (`id`, `categorie_title`) VALUES
(1, 'Популярное'),
(2, 'Новинки'),
(3, 'старинки'),
(4, 'ыа'),
(5, 'fs'),
(6, 'sdg'),
(7, 'ывп'),
(8, 'dd'),
(9, 'sd'),
(10, 'ss'),
(11, 'zf'),
(12, 'происходит'),
(13, 'вп'),
(14, 'ываыва'),
(15, 'ывпывп');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `login` varchar(30) CHARACTER SET utf8 NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `password`) VALUES
(1, 'admin', 'd8578edf8458ce06fbc5bb76a58c5ca4'),
(2, 'admin2', 'd8578edf8458ce06fbc5bb76a58c5ca4'),
(4, 'admin2', '6dbd0fe19c9a301c4708287780df41a2'),
(5, 'admin3', 'd8578edf8458ce06fbc5bb76a58c5ca4'),
(6, 'admin', 'c1d7e3cd6cae490ced51924c53b6fe54');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `films`
--
ALTER TABLE `films`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `fim_categorie`
--
ALTER TABLE `fim_categorie`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `films`
--
ALTER TABLE `films`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT для таблицы `fim_categorie`
--
ALTER TABLE `fim_categorie`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
